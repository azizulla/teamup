//
//  InvitationEntity+CoreDataClass.swift
//  TeamUp
//
//  Created by Aziz on 2017-12-01.
//  Copyright © 2017 Aziz. All rights reserved.
//

import Foundation
import CoreData

@objc(InvitationEntity)
public class InvitationEntity: NSManagedObject {

}
