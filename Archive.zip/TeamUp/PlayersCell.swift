//
//  PlayersCell.swift
//  TeamUp
//
//  Created by Aziz on 2017-11-29.
//  Copyright © 2017 Aziz. All rights reserved.
//

import UIKit



class PlayersCell: UITableViewCell {
    
    @IBOutlet weak var friendNameLabel: UILabel!
    @IBOutlet weak var friendInviteButton: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
        
    }


